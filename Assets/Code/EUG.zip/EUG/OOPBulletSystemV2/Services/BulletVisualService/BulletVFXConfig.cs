﻿using Cysharp.Threading.Tasks;
using System.Collections.Generic;
using UnityEngine;
// ============================================================================
// BulletVisualService v2
//
// 回答你的問題：「傷害 Strategy 需要另一個 BulletVisualService 嗎？」
//
//   不需要。
//   做法：BulletHitEvent 帶 HitType（Single / Aoe / Dot）
//   VisualService 依 HitType switch 播放對應特效。
//   Strategy 只負責傷害邏輯，完全不碰 VFX。
//   VFX 層只訂閱 EventBus 事件，不需要知道 Strategy 的存在。
//
// ============================================================================
namespace Nobeta.EUG.BulletSystemV2.OOP.UnityBridge
{
    [System.Serializable]
    public class BulletVFXConfig
    {
        public BulletType Type;

        [Header("基礎視覺")]
        public GameObject BulletVisualPrefab;
        [Header("拖尾特效 Trail")]
        public GameObject TrailRendererPrefab;         // 拖尾粒子
        public float trailLifetime = 2f;       // 子彈銷毀後拖尾停留時間
        [Header("槍口閃光")]
        public GameObject MuzzleFlashPrefab;
        public float muzzleFlashLifetime = 1f;
        [Header("擊中特效 BulletHit")]
        public GameObject HitEffectPrefab;     // 擊中特效
        public float hitEffectLifetime = 1f;

        [Header("命中特效 (依 HitType)")]
        public GameObject HitEffectSingle;   // 單體命中
        public GameObject HitEffectAoe;      // 範圍爆炸（半徑會 Scale 到 AoeRadius）
        public GameObject HitEffectDot;      // DoT 開始（燃燒 / 中毒貼圖）
    }  
}