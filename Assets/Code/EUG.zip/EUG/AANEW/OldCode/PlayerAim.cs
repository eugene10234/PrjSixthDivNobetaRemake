using System;
using Unity.Cinemachine;
using UnityEditor;
using UnityEngine;

namespace Nobeta.Scripts.PlayerSpace
{
    public class PlayerAim : MonoBehaviour
    {
        //private IPlayer player;


        [Header("Aim Viusal - Laser")]
        [SerializeField] private LineRenderer aimLaser; // this component is on the waepon holder(child of a player)

        [Header("Aim control")]
        [SerializeField] private Transform aim;

        [SerializeField] private bool isAimingPrecisly;
        [SerializeField] private bool isLockingToTarget;

        [Header("Camera control")]
        [SerializeField] private Transform cameraTarget;
        [SerializeField] private Transform mFollowPoint;

        private Vector3 _desireForward;
        private Vector3 _desireAngleVector = new Vector3(0,0,1f);
        [SerializeField] private float mHorizontalSensetivity = 5f;
        [SerializeField] private float mVerticalSensetivity = 2f;
        [Range(.5f, 1)]
        //[SerializeField] private float minCameraDistance = 1.5f;
        //[Range(1, 3f)]
        //[SerializeField] private float maxCameraDistance = 4;
        //[Range(3f, 5f)]
        //[SerializeField] private float cameraSensetivity = 5f;

        [Space]

        [SerializeField] private LayerMask aimLayerMask;

        private Vector2 mouseInput;
        private RaycastHit lastKnownMouseHit;

        private void Start()
        {
            // ����l���׵�����e���骺���סA�קK����
            Vector3 currentEuler = mFollowPoint.eulerAngles;
            m_Yaw = currentEuler.y;
            m_Pitch = currentEuler.x;
            // �`�N�GEuler x ���ɷ|�W�L 180 �סA�Y�����D�ݰ� Mathf.DeltaAngle �ഫ

            //player = GetComponent<mbPlayer>();
            AssignInputEvents();
        }
        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.P))
                isAimingPrecisly = !isAimingPrecisly;

            if (Input.GetKeyDown(KeyCode.L))
                isLockingToTarget = !isLockingToTarget;
            //Debug.Log("s"+DateTime.Now+GetMouseHitInfo().point);
            //UpdateAimVisuals();
            //UpdateAimPosition();
            //UpdateCameraPosition();
            //UpdateCameraRotation();
        }
        private void LateUpdate()
        {
            UpdateCameraRotation();
        }
        // �b���O�����w�q�p���ܼơA�ΨӰO�����e����
        private float m_Pitch = 0f; // �W�U����
        private float m_Yaw = 0f;   // ���k����
        private void UpdateCameraRotation()
        {
            // 1. ���o�ò֥[��J��
            m_Yaw += Input.GetAxis("Mouse X") * mHorizontalSensetivity;
            m_Pitch -= Input.GetAxis("Mouse Y") * mVerticalSensetivity; // �q�` Y �b��J�ݭn����

            // 2. ��������ס]����½��^
            // ���] 0 �O�����A90 �O�ݸ}�U�A-90 �O�ݤѪ�
            m_Pitch = Mathf.Clamp(m_Pitch, -89f, 89f);

            // 3. �����p��s���|���Ʊ���
            // �ϥ� Euler �զX�X�s������A�o���|���W�@�V�����ా���v�T
            Quaternion targetRotation = Quaternion.Euler(m_Pitch, m_Yaw, 0f);

            // 4. ��s _desireForward (�u��������V�A�Ω󨤦��ਭ�޿�)
            // �o�̧ڭ̥u�ϥ� m_Yaw�A���� m_Pitch
            _desireForward = Quaternion.Euler(0f, m_Yaw, 0f) * Vector3.forward;

            // 5. �M�α���
            mFollowPoint.rotation = targetRotation;
        }

        //private void UpdateAimVisuals()
        //{
        //    Transform gunPoint = player.weapon.GunPoint();
        //    Vector3 laserDirection = player.weapon.BulletDirection();

        //    float laserTipLenght = .5f;
        //    float gunDistance = 4f;

        //    Vector3 endPoint = gunPoint.position + laserDirection * gunDistance;

        //    if (Physics.Raycast(gunPoint.position, laserDirection, out RaycastHit hit, gunDistance))
        //    {
        //        endPoint = hit.point;
        //        laserTipLenght = 0;
        //    }

        //    aimLaser.SetPosition(0, gunPoint.position);
        //    aimLaser.SetPosition(1, endPoint);
        //    aimLaser.SetPosition(2, endPoint + laserDirection * laserTipLenght);
        //}
        //private void UpdateAimPosition()
        //{
        //    Transform target = Target();

        //    if (target != null && isLockingToTarget)
        //    {
        //        aim.position = target.position;
        //        return;
        //    }

        //    aim.position = GetMouseHitInfo().point;

        //    if (!isAimingPrecisly)
        //        aim.position = new Vector3(aim.position.x, transform.position.y + 1, aim.position.z);
        //}




        //public Transform Target()
        //{
        //    Transform target = null;

        //    if (GetMouseHitInfo().transform.GetComponent<Target>() != null)
        //    {
        //        target = GetMouseHitInfo().transform;
        //    }

        //    return target;
        //}
        public Transform Aim() => aim;
        public bool CanAimPrecisly() => isAimingPrecisly;
        public Vector2 GetMouseInfo()
        {
            return mouseInput;
        }
        public Vector3 GetDesireForward()
        {
            Vector3 flattenedForward = Vector3.ProjectOnPlane(mFollowPoint.forward, Vector3.up).normalized;
            return _desireForward;
        }
        public Vector3 GetDesireAngleVector()
        {
            return _desireAngleVector;
        }
        public RaycastHit GetMouseHitInfo()
        {
            Ray ray = Camera.main.ScreenPointToRay(mouseInput);
           
            if (Physics.Raycast(ray, out var hitInfo, Mathf.Infinity, aimLayerMask))
            {
                //Debug.Log("Hit: " + hitInfo.transform.name + hitInfo.transform.position +DateTime.Now);
           
                lastKnownMouseHit = hitInfo;
                return hitInfo;
            }

            return lastKnownMouseHit;
        }
        private void OnDrawGizmos()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawSphere(lastKnownMouseHit.point, .2f);
        }
        #region Camera Region

        //private void UpdateCameraPosition()
        //{
        //    cameraTarget.position =
        //                Vector3.Lerp(cameraTarget.position, DesieredCameraPosition(), cameraSensetivity * Time.deltaTime);
        //}

        //private Vector3 DesieredCameraPosition()
        //{
        //    float actualMaxCameraDistance = player.movement.moveInput.y < -.5f ? minCameraDistance : maxCameraDistance;

        //    Vector3 desiredCameraPosition = GetMouseHitInfo().point;
        //    Vector3 aimDirection = (desiredCameraPosition - transform.position).normalized;

        //    float distanceToDesierdPosition = Vector3.Distance(transform.position, desiredCameraPosition);
        //    float clampedDistance = Mathf.Clamp(distanceToDesierdPosition, minCameraDistance, actualMaxCameraDistance);

        //    desiredCameraPosition = transform.position + aimDirection * clampedDistance;
        //    desiredCameraPosition.y = transform.position.y + 1;

        //    return desiredCameraPosition;
        //}

        #endregion

        private void AssignInputEvents()
        {
            //controls = new PlayerControls();

            //controls.Character.Aim.performed += context => mouseInput = context.ReadValue<Vector2>();
            //controls.Character.Aim.canceled += context => mouseInput = Vector2.zero;
        }

    }
}